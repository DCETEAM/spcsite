<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SubCategory;
use App\Models\MainCategory;

class SubcategoryController extends Controller
{
    public function index()
    {
        $subcategories = SubCategory::with('maincategory')->get();
        return view('admin.subcategories.index', compact('subcategories'));
    }

    public function create()
    {
        $maincategories = MainCategory::all();
        return view('admin.subcategories.create', compact('maincategories'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'subcategory_name' => 'required|string|max:255',
            'maincategory_id' => 'required|exists:maincategories,maincategory_id',
            'subcategory_image' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
        ]);

        $path = null;
        if ($request->hasFile('subcategory_image')) {
            $path = $request->file('subcategory_image')->store('uploads/subcategories', 'public');
        }

        SubCategory::create([
            'subcategory_name' => $request->subcategory_name,
            'maincategory_id' => $request->maincategory_id,
            'subcategory_image' => $path,
        ]);

        return redirect()->route('admin.subcategories.index')->with('success', 'Subcategory added successfully!');
    }

    public function edit($id)
    {
        $subcategory = SubCategory::findOrFail($id);
        $maincategories = MainCategory::all();
        return view('admin.subcategories.edit', compact('subcategory', 'maincategories'));
    }

    public function update(Request $request, $id)
    {
        $subcategory = SubCategory::findOrFail($id);

        $request->validate([
            'subcategory_name' => 'required|string|max:255',
            'maincategory_id' => 'required|exists:maincategories,maincategory_id',
            'subcategory_image' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
        ]);

        $path = $subcategory->subcategory_image;
        if ($request->hasFile('subcategory_image')) {
            $path = $request->file('subcategory_image')->store('uploads/subcategories', 'public');
        }

        $subcategory->update([
            'subcategory_name' => $request->subcategory_name,
            'maincategory_id' => $request->maincategory_id,
            'subcategory_image' => $path,
        ]);

        return redirect()->route('admin.subcategories.index')->with('success', 'Subcategory updated successfully!');
    }

    public function destroy($id)
    {
        $subcategory = SubCategory::findOrFail($id);
        $subcategory->delete();
        return redirect()->route('admin.subcategories.index')->with('success', 'Subcategory deleted successfully!');
    }
    public function getSubcategories($maincategory_id)
{
    $subcategories = SubCategory::where('maincategory_id', $maincategory_id)
        ->select('subcategory_id', 'subcategory_name')
        ->orderBy('subcategory_name')
        ->get();

    return response()->json($subcategories);
}
 public function getByMainMulti(Request $request)
    {
        $ids = explode(',', $request->query('ids'));
        $subcategories = SubCategory::whereIn('maincategory_id', $ids)
            ->select('subcategory_id', 'subcategory_name')
            ->orderBy('subcategory_name')
            ->get();

        return response()->json($subcategories);
    }
}
