<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\About;
use App\Models\MainCategory;

class HomeController extends Controller
{
    public function index()
    {
        $about = About::first(); // Fetch about section data
        $categories = MainCategory::all(); // Fetch categories for dynamic listing
        return view('welcome', compact('about', 'categories'));
    }
}
