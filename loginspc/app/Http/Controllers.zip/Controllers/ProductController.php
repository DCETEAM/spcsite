<?php

// ...existing code...
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\MainCategory;
use App\Models\SubCategory;
use App\Models\Product;

class ProductController extends Controller
{
    // 🟢 Show all categories (Home page)
    public function index()
    {
        $categories = MainCategory::all();
        $activeCategoryId = $categories->first()->maincategory_id ?? null;

        $subcategories = SubCategory::where('maincategory_id', $activeCategoryId)->get();

        $products = Product::whereJsonContains('main_category_ids', $activeCategoryId)->get();

        return view('products.index', compact('categories', 'subcategories', 'products', 'activeCategoryId'))
            ->with('viewType', 'products');
    }

    // 🟢 Show products by main category
    public function showCategory($id)
    {
        $categories = MainCategory::all();
        $activeCategoryId = $id;
        $subcategories = SubCategory::where('maincategory_id', $id)->get();

        $products = Product::whereJsonContains('main_category_ids', $id)->get();

        return view('products.index', compact('categories', 'subcategories', 'products', 'activeCategoryId'))
            ->with('viewType', 'products');
    }

    // 🟢 Show products by subcategory
    public function showSubcategory($id)
    {
        $sub = SubCategory::findOrFail($id);
        $categories = MainCategory::all();
        $activeCategoryId = $sub->maincategory_id;
        $subcategories = SubCategory::where('maincategory_id', $sub->maincategory_id)->get();

        $products = Product::whereJsonContains('sub_category_ids', $id)->get();

        return view('products.index', compact('categories', 'subcategories', 'products', 'activeCategoryId'))
            ->with('viewType', 'products');
    }

    // 🟣 Show single product by slug
    public function showPublic($slug)
    {
        $product = Product::where('slug', $slug)->firstOrFail();
        return view('show', compact('product'));
    }
 public function show($slug)
    {
        $product = Product::where('slug', $slug)->firstOrFail();
        return view('show', compact('product'));
    }
    
}