<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Subcategory extends Model
{
    use HasFactory;

    protected $primaryKey = 'subcategory_id';

    protected $fillable = [
        'subcategory_name',
        'subcategory_image',
        'maincategory_id',
    ];

    // A subcategory belongs to a main category
    public function maincategory()
    {
        return $this->belongsTo(MainCategory::class, 'maincategory_id', 'maincategory_id');
    }

    // A subcategory has many products
    public function products()
    {
        return $this->hasMany(Product::class, 'sub_category_id', 'subcategory_id');
    }
}
