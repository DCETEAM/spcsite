<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Maincategory extends Model
{
    use HasFactory;

    protected $primaryKey = 'maincategory_id';

    protected $fillable = [
        'maincategory_name',
        'maincategory_image',
    ];

    // A main category has many subcategories
    public function subcategories()
    {
        return $this->hasMany(SubCategory::class, 'maincategory_id', 'maincategory_id');
    }

    // A main category has many products
    public function products()
    {
        return $this->hasMany(Product::class, 'main_category_id', 'maincategory_id');
    }
}
